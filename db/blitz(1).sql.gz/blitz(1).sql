-- phpMyAdmin SQL Dump
-- version 3.4.5deb1
-- http://www.phpmyadmin.net
--
-- Vært: localhost
-- Genereringstid: 19. 03 2013 kl. 13:16:25
-- Serverversion: 5.1.66
-- PHP-version: 5.3.6-13ubuntu3.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `blitz`
--

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `events`
--

CREATE TABLE IF NOT EXISTS `events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dato` date NOT NULL,
  `dato_text` varchar(40) NOT NULL,
  `titel` varchar(100) DEFAULT NULL,
  `beskrivelse` text,
  `arrangoer` varchar(50) DEFAULT NULL,
  `kontaktperson` varchar(50) DEFAULT NULL,
  `kontaktperson_mail` varchar(50) DEFAULT NULL,
  `lat` varchar(20) DEFAULT NULL,
  `long` varchar(20) DEFAULT NULL,
  `stedbeskrivelse` text,
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Data dump for tabellen `events`
--

INSERT INTO `events` (`id`, `dato`, `dato_text`, `titel`, `beskrivelse`, `arrangoer`, `kontaktperson`, `kontaktperson_mail`, `lat`, `long`, `stedbeskrivelse`) VALUES
(1, '2013-05-17', 'Fredag 17.05.2013', 'Bioblitz 2013', 'Bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla ', 'Statens Nutuhistoriske Museum', 'Admiral H.A.V. Guus', 'havguus@snm.ku.dk', '55.65606666697482', '12.575547695159912', 'Stedbrskrivelse stedbeskrivelse stedbeskrivelse stedbeskrivelse  stedbeskrivelse stedbeskrivelse stedbeskrivelse stedbeskrivelse stedbeskrivelse stedbeskrivelse stedbeskrivelse stedbeskrivelse stedbeskrivelse stedbeskrivelse stedbeskrivelse stedbeskrivelse stedbeskrivelse stedbeskrivelse stedbeskrivelse stedbeskrivelse stedbeskrivelse stedbeskrivelse stedbeskrivelse stedbeskrivelse stedbeskrivelse stedbeskrivelse stedbeskrivelse stedbeskrivelse stedbeskrivelse stedbeskrivelse stedbeskrivelse stedbeskrivelse stedbeskrivelse stedbeskrivelse stedbeskrivelse stedbeskrivelse stedbeskrivelse stedbeskrivelse stedbeskrivelse '),
(3, '2013-07-23', 'Tirsdag 23.07.2013', 'Kryptoblitz på Amager Fælled', 'bla bla bla  bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla', 'Dansk Kryptologisk Selskab', 'Kaj &quot;kryptokaj&quot; Kallesen', 'kryptokaj@dks.org', '55.65606666697482', '12.575547695159912', 'bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla');

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `event_fund`
--

CREATE TABLE IF NOT EXISTS `event_fund` (
  `LNR` int(11) NOT NULL AUTO_INCREMENT,
  `_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `taxon` varchar(80) NOT NULL,
  `dknavn` varchar(80) DEFAULT NULL,
  `finder_navn` varchar(50) NOT NULL,
  `finder_hold` varchar(50) DEFAULT NULL,
  `finder_gruppe` varchar(50) DEFAULT NULL,
  `lat` varchar(21) NOT NULL,
  `lng` varchar(21) NOT NULL,
  `indtaster` varchar(40) NOT NULL,
  `bestemmer` varchar(40) NOT NULL,
  `first_occurrence` int(1) NOT NULL,
  `artsgruppe` varchar(50) DEFAULT NULL,
  `artsgruppe_dk` varchar(50) DEFAULT NULL,
  UNIQUE KEY `LNR` (`LNR`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=36 ;

--
-- Data dump for tabellen `event_fund`
--

INSERT INTO `event_fund` (`LNR`, `_timestamp`, `taxon`, `dknavn`, `finder_navn`, `finder_hold`, `finder_gruppe`, `lat`, `lng`, `indtaster`, `bestemmer`, `first_occurrence`, `artsgruppe`, `artsgruppe_dk`) VALUES
(1, '2013-03-15 12:30:56', 'Asarum europaeum', 'Hasselurt', 'fsfsdf', 'fsdfs', 'dsfsd', '55.676097', '12.568337', 'sfsdf', 'sdfsf', 1, NULL, NULL),
(2, '2013-03-15 12:30:59', 'Asarum europaeum', 'Hasselurt', 'fsfsdf', 'fsdfs', 'dsfsd', '55.676097', '12.568337', 'sfsdf', 'sdfsf', 0, NULL, NULL),
(3, '2013-03-15 12:31:01', 'Asarum europaeum', 'Hasselurt', 'fsfsdf', 'fsdfs', 'dsfsd', '55.676097', '12.568337', 'sfsdf', 'sdfsf', 0, NULL, NULL),
(4, '2013-03-15 12:31:20', 'Bacidia circumspecta', 'Skov-tensporelav', 'fsfsdf', 'fsdfs', 'dsfsd', '55.676097', '12.568337', 'sfsdf', 'sdfsf', 1, NULL, NULL),
(5, '2013-03-15 12:31:21', 'Bacidia circumspecta', 'Skov-tensporelav', 'fsfsdf', 'fsdfs', 'dsfsd', '55.676097', '12.568337', 'sfsdf', 'sdfsf', 0, NULL, NULL),
(6, '2013-03-15 12:31:22', 'Bacidia circumspecta', 'Skov-tensporelav', 'fsfsdf', 'fsdfs', 'dsfsd', '55.676097', '12.568337', 'sfsdf', 'sdfsf', 0, NULL, NULL),
(7, '2013-03-15 12:31:29', 'Bacidia circumspecta', 'Skov-tensporelav', 'fsfsdf', 'fsdfs', 'dsfsd', '55.676097', '12.568337', 'sfsdf', 'sdfsf', 0, NULL, NULL),
(8, '2013-03-15 12:55:09', 'Esox lucius', 'Gedde', 'knud bent', 'fdsdfsdf', 'qweerrt', '55.676097', '12.568337', 'wqwqwq', '', 1, NULL, NULL),
(9, '2013-03-15 12:58:31', 'Belone belone', 'Hornfisk', 'saassa', 'sasasa', 'sasasa', '55.676097', '12.568337', 'sasasa', 'sasasa', 1, NULL, NULL),
(10, '2013-03-15 13:08:19', 'Gadimyxa atlantica', '', 'wqwq', 'wqwq', 'wqwq', '55.676097', '12.568337', 'wqwqwq', 'wqwq', 1, NULL, NULL),
(11, '2013-03-15 13:09:45', 'Tachinus marginellus', '', 'aaa', 'aaa', 'aaa', '55.676097', '12.568337', 'aaawqwqwq', 'aaa', 1, NULL, NULL),
(12, '2013-03-15 13:10:09', 'Keissleriella culmifida', '', 'aaa', 'aaa', 'aaa', '55.676097', '12.568337', 'aaawqwqwq', 'aaa', 1, NULL, NULL),
(13, '2013-03-15 13:20:54', 'Ulocladium consortiale', '', 'aaa', 'aaa', 'aaa', '55.676097', '12.568337', 'aaawqwqwq', 'aaa', 1, NULL, NULL),
(14, '2013-03-15 13:22:37', 'Ochlerotatus annulipes', '', 'aaa', 'aaa', 'aaa', '55.676097', '12.568337', 'aaawqwqwq', 'aaa', 1, NULL, NULL),
(15, '2013-03-15 13:23:00', 'Pachygnathus villosus', '', 'aaa', 'aaa', 'aaa', '55.676097', '12.568337', 'aaawqwqwq', 'aaa', 1, NULL, NULL),
(16, '2013-03-15 14:10:42', '', '', '', '', '', '55.676386602523266', '12.56908893585205', '', '', 1, NULL, NULL),
(17, '2013-03-15 14:10:45', '', '', '', '', '', '55.676386602523266', '12.56908893585205', '', '', 0, NULL, NULL),
(18, '2013-03-15 14:10:47', '', '', '', '', '', '55.676386602523266', '12.56908893585205', '', '', 0, NULL, NULL),
(19, '2013-03-15 14:16:48', '', '', '', '', '', '55.676097', '12.568337', '', '', 0, NULL, NULL),
(20, '2013-03-15 14:38:04', 'Aschitus aeneiventris', '', '', 'sss', 'sss', '55.676097', '12.568337', 'sss', '', 1, NULL, NULL),
(21, '2013-03-15 14:39:43', 'Rabdophaga jaapi', '', '', '', 'dddd', '55.676097', '12.568337', 'dddd', 'ddd', 1, NULL, NULL),
(22, '2013-03-15 14:48:13', 'Habrosyne pyritoides', 'Klyngerspinder', 'sdf', 'sdfsdf', 'sdfsdf', '55.677427125187855', '12.566642761230469', 'sdfsdf', 'sdf', 1, NULL, NULL),
(23, '2013-03-15 14:55:43', 'Chaenotheca trichialis', 'GrÃ¥ knappenÃ¥lslav', 'dfdffd', '', 'ddfdf', '55.676097', '12.568337', 'sdfsdf', 'fffff', 1, NULL, NULL),
(24, '2013-03-15 14:55:52', '', '', '', '', '', '', '', '', '', 0, NULL, NULL),
(25, '2013-03-15 14:58:47', 'Rabdophaga marginemtorquens', 'BÃ¥ndpilbladgalmyg', 'xcvxcvxcvxcv', 'ddd', 'dd', '55.676097', '12.568337', 'cxcvcxcv', 'dsfsd', 1, NULL, NULL),
(26, '2013-03-19 09:49:58', 'Taraxacum epacroides', 'Rosen-vejmÃ¦lkebÃ¸tte', 'sdfdfs', 'sdfsdf', 'sdfdsf', '55.65606666697482', '12.575547695159912', 'sdfsdfdfs', 'sdfsdf', 1, '', ''),
(27, '2013-03-19 09:52:15', 'Gabrius nigritulus', '', 'fsdf', 'sdfsd', 'fdfs', '55.65606666697482', '12.575547695159912', 'sfsdf', 'sdfsdf', 1, '', ''),
(28, '2013-03-19 09:53:24', 'Habronyx nigricornis', '', 'sdfsdf', 'fsdf', 'dfsdfsd', '55.65606666697482', '12.575547695159912', 'sdfsdf', 'sdfsdf', 1, '', ''),
(29, '2013-03-19 10:08:02', 'Dacnusa ergeteles', '', 'sdf', 'sdfsdf', 'sdfsfd', '55.65606666697482', '12.575547695159912', 'sdfdssdf', 'sdfsdfsdf', 1, 'Hymenoptera', 'ï¿½revinger'),
(30, '2013-03-19 10:08:46', 'Jaapiella hypochoeridis', '', 'sdfsdfsdf', 'sdff', 'sdfsdf', '55.65606666697482', '12.575547695159912', 'sdfsdfdsf', 'dfsdfsdfdfs', 1, 'Diptera', 'Tovinger'),
(31, '2013-03-19 10:09:02', 'Habrolepis dalmanni', '', 'sdfsdfsdf', 'sdff', 'sdfsdf', '55.65606666697482', '12.575547695159912', 'sdfsdfdsf', 'dfsdfsdfdfs', 1, 'Hymenoptera', 'Ã…revinger'),
(32, '2013-03-19 10:09:09', 'Habrolepis dalmanni', '', 'sdfsdfsdf', 'sdff', 'sdfsdf', '55.65606666697482', '12.575547695159912', 'sdfsdfdsf', 'dfsdfsdfdfs', 0, 'Hymenoptera', 'Ã…revinger'),
(33, '2013-03-19 10:13:29', 'Gabrius osseticus', '', 'sdfsdf', 'sdfsdfsdf', 'sdfsdfsdf', '55.65606666697482', '12.575547695159912', 'sdfsdfsdf', 'sdfsdf', 1, 'Coleoptera', 'Biller'),
(34, '2013-03-19 10:14:01', 'sdfdsf', 'sdf', 'sddfsdf', 'sdfsdf', 'sdfsdf', '55.65606666697482', '12.575547695159912', 'sdffdfs', 'sdfsdf', 1, '', ''),
(35, '2013-03-19 10:14:10', 'Fagisyrphus cinctus', 'BÃ¸ge-svirreflue', 'sdfsdf', 'sdf', 'sdfddsf', '55.65606666697482', '12.575547695159912', 'sdfsdfsdf', 'sdfsdf', 1, 'Diptera', 'Tovinger');

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `event_login`
--

CREATE TABLE IF NOT EXISTS `event_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brugernavn` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Data dump for tabellen `event_login`
--

INSERT INTO `event_login` (`id`, `brugernavn`, `password`, `email`) VALUES
(1, 'lotte', 'lotte', 'lendsleff@snm.ku.dk');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
